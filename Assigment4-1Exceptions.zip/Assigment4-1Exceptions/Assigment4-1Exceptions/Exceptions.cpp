// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>

class CustomException : public std::exception {             //Custom exception declaration
public:                                                     //inherits from std::exception
    virtual const char* what() const throw() {
            return "Custom exception thrown";               //.what() is overridden with a new message
        }
};

bool do_even_more_custom_application_logic()
{
    // DONE: Throw any standard exception
    throw std::runtime_error("do_even_more_custom_application_logic failed"); //runtime_error is a std::exception
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    // DONE: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;
    try    // Method is called in the "if" statement, so the wole block is wrapped in the "try" block
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& exception) // Catch block for standard exceptions
    {
        std::cerr << "Exception caught: " << exception.what() << std::endl;
    }

    // DONE: Throw a custom exception derived from std::exception
    //  and catch it explictly in main
    throw CustomException(); // throws an instance of the customException class
    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // DONE: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    if (den == 0) // Conditionally throws a standard exception to prevent an error
    {
        throw std::runtime_error("cannot divide by zero");
    }
    return (num / den); // if no exception, proceed.
}

void do_division() noexcept
{
    //  DONE: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;
    try 
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::exception& exception) // Catch block for div by 0 exception
    {
        std::cerr << "Exception caught: " << exception.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;  


    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.
    try
    {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& myException) // Catch block for custom exception
    {
        std::cerr << "Custom exception caught: " << myException.what() << std::endl;
    }
    catch (const std::exception& exception)  // Catch block for standard exceptions
    {
        std::cerr << "std::exception caught: " << exception.what() << std::endl;
    }
    catch (...) // Catch block for any uncaught exceptions
    {
        std::cerr << "Uncaught exception" << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu